document.addEventListener('DOMContentLoaded', () => {
    const registrationPage = document.getElementById('registration-page');
    const mainPage = document.getElementById('main-page');
    const registrationForm = document.getElementById('registration-form');
    const searchBar = document.getElementById('search-bar');

    // Registration form submission
    registrationForm.addEventListener('submit', (event) => {
        event.preventDefault();

        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;

        // You can save user data here (e.g., localStorage or API)
        console.log(`Name: ${name}, Email: ${email},`);

        // Show the main page
        registrationPage.classList.add('hidden');
        mainPage.classList.remove('hidden');
    });
    function startup() {
        video = document.getElementById('video');
        canvas = document.getElementById('canvas');
        photo = document.getElementById('photo');
        startButton = document.getElementById('start-button');
    }

    // Search functionality
    searchBar.addEventListener('input', (event) => {
        const query = event.target.value.toLowerCase();
        const foodCards = document.querySelectorAll('.food-card');

        foodCards.forEach(card => {
            const foodName = card.querySelector('h3').textContent.toLowerCase();
            card.style.display = foodName.includes(query) ? 'flex' : 'none';
        });
    });
});
